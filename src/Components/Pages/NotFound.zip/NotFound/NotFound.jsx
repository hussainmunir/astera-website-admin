import React from 'react'
import Section1 from './Section1'

export function NotFound () {
  return (
    <div>
      <Section1 />
    </div>
  )
}

export default NotFound
