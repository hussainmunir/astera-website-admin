import React from 'react'
import { Discovertitle } from './Discovertitle'
import { Discoversection1 } from './Discoversection1'
import { Discoversection2 } from './Discoversection2'
import { Discoversection3 } from './Discoversection3'
import { Discoversection4 } from './Discoversection4'
import { Discoversection5 } from './Discoversection5'
import { Discoversection6 } from './Discoversection6'
import { Discoversection7 } from './Discoversection7'



export function Discover () {
  return (
    <div>
      <Discovertitle/>
      <Discoversection1/>
      <Discoversection2/>
      <Discoversection3/>
      <Discoversection4/>
      <Discoversection5/>
      <Discoversection6/>
      <Discoversection7/>

      
    </div>
  )
}
